# SMU MSDS homework Assignment3
MSDS 6306 Homework Repository for Assignment 3

## View RMD output
http://htmlpreview.github.io/?https://github.com/AdeelAbbasi/SMUMSDShomeworkAssignment3/blob/master/Homework/Live_Session_Assignment03.html

## Purpose of the repository, 
Purpose of this repository to keep track of home work assignment files

## Topics included, 
Topics included are for R programming, some dataset packages, reading files etc.

## Sources for the material 
https://github.com/rudeboybert/fivethirtyeight

## Contact information 
Please contact me at [aabbasi at smu dot edu] for any question or suggestion

